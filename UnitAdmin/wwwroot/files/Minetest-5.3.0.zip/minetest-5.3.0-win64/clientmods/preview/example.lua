print("Loaded example file!, loading more examples")
dofile(core.get_modpath(core.get_current_modname()) .. "/examples/first.lua")
