Minetest Game mod: vessels
==========================
See license.txt for license information.

Authors of source code
----------------------
Originally by Vanessa Ezekowitz (LGPLv2.1+)
Modified by Perttu Ahola <celeron55@gmail.com> (LGPLv2.1+)
Various Minetest developers and contributors (LGPLv2.1+)

Authors of media (textures)
---------------------------
All not listed below, Vanessa Ezekowitz (CC BY-SA 3.0)

The following textures were modified by Thomas-S (CC BY-SA 3.0):
  vessels_drinking_glass.png
  vessels_drinking_glass_inv.png
  vessels_glass_bottle.png
  vessels_steel_bottle.png

The following texture was created by Wuzzy (CC BY-SA 3.0):
  vessels_shelf_slot.png (based on vessels_glass_bottle.png)
