# Test Nodes

This mod contains a bunch of basic nodes to test development stuff.
Most nodes are kept as minimal as possible in order to show off one particular feature of the engine, to make testing stuff easier.

This mod includes tests for:

* drawtypes
* paramtype2's
* node properties such as damage, drowning, falling, etc.
* other random stuff
